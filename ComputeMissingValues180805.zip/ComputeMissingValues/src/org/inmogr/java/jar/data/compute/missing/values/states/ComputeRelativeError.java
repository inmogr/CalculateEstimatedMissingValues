package org.inmogr.java.jar.data.compute.missing.values.states;

import java.util.ArrayList;
import java.util.List;

import org.inmogr.java.jar.data.compute.missing.values.classes.DataSet;
import org.inmogr.java.jar.data.compute.missing.values.classes.RowExt;

public class ComputeRelativeError {
	
	// just resulted from earlier states
	public DataSet learning, testingIncomplete, crowdSource, calculatedValues;
	
	/** the desired margin of error (range 0.00<->1.00) for calculated values to be accepted */
	double marginOfError;
	
	/** the value difference (error) in the original order for average error calculation and errors exportion */
	protected List<Double> totalError = new ArrayList<>();
	
	/** the result sub set with missing values that could not be computed */
	public DataSet finalCrowdSource;
	
	/** the result sub set with missing values that have been successfully computed */
	public DataSet finalCalculatedValues;
	
	public ComputeRelativeError(DataSet learning, DataSet testingIncomplete, DataSet crowdSource, DataSet calculatedValues, double marginOfError) {
		this.learning = learning;
		this.testingIncomplete = testingIncomplete;
		this.crowdSource = crowdSource;
		this.calculatedValues = calculatedValues;
		this.marginOfError = marginOfError;
	}
	
	protected void checkRelativeError() {
		ArrayList<RowExt> rowsOri = this.learning.getRows();
		ArrayList<RowExt> rowsMis = this.testingIncomplete.getRows();
		ArrayList<RowExt> rowsCal = this.calculatedValues.getRows();
		ArrayList<RowExt> rowsCalFinal = new ArrayList<>();
		ArrayList<RowExt> rowsCroAdditional = new ArrayList<>();
		for (int index = 0; index < rowsCal.size(); index++) {
			RowExt rowMis = new RowExt(rowsMis.get(index));
			RowExt rowCal = new RowExt(rowsCal.get(index));
			RowExt rowOri = new RowExt(rowsOri.get(rowCal.getLocation()));
			if (isCalculatedValueWithinMargin(rowMis, rowCal, rowOri)) {
				rowsCalFinal.add(rowCal);
			}
			else {
				rowsCroAdditional.add(rowMis);
			}
		}
		this.finalCalculatedValues = new DataSet(this.learning.getAttributes(), rowsCalFinal);
		rowsCroAdditional.addAll(this.crowdSource.getRows());
		this.finalCrowdSource = new DataSet(this.learning.getAttributes(), rowsCroAdditional);
	}

	protected boolean isCalculatedValueWithinMargin(RowExt rowMis, RowExt rowCal, RowExt rowOri) {
		String[] attributes = rowMis.getAttributesWithMissingValue();
		for (int index = 0; index < attributes.length; index++) {
			double valueCal = rowCal.getValue(attributes[index]);
			double valueOri = rowOri.getValue(attributes[index]);
			//System.out.println(valueCal + " <---> " + valueOri);
			if (isBelowMarginOfError(valueCal, valueOri)) {
				return false;
			}
		}
		return true;
	}

	protected boolean isBelowMarginOfError(double v1, double v2) {
		double diff = Math.abs(v1 - v2);
		this.totalError.add(diff);
		if (v1 > v2)
			return (v2 / v1) < marginOfError;
		return (v1 / v2) < marginOfError;
	}

}
