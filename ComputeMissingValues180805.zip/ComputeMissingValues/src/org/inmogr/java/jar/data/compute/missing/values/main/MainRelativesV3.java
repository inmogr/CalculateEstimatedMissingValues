package org.inmogr.java.jar.data.compute.missing.values.main;

import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import org.inmogr.java.jar.data.compute.missing.values.classes.DataSet;
import org.inmogr.java.jar.data.compute.missing.values.classes.RowExt;
import org.inmogr.java.jar.data.compute.missing.values.states.ComputeRelativeError;
import org.inmogr.java.jar.data.compute.missing.values.states.DataExportion;
import org.inmogr.java.jar.data.compute.missing.values.states.DataPreProcessing;
import org.inmogr.java.jar.data.compute.missing.values.states.DataReplacementUsingMFR;

/** replaces the sequential rows locations to user defined ones */
public class MainRelativesV3 {
	
	public MainRelativesV3() {
		Scanner scanner = new Scanner(System.in);
		//
		//
		//
		System.out.println("Please provide the path of the original (complete) data set (file format must be CSV):");
		String pathOfOriginalDataSet = scanner.nextLine();
		//
		//
		//
		System.out.println("Please provide the path of the missing (incomplete) data set (file format must be CSV):");
		String pathOfDataSetWithMissingValues = scanner.nextLine();
		//
		//
		//
		System.out.println("Please provide the path of the missing rows' original reference (file format must be CSV of a single column):");
		String pathOfMissingRowsReference = scanner.nextLine();
		//
		//
		//
		System.out.println("Type the column's (attribute's) name of the primary key:");
		String pk = scanner.nextLine();
		System.out.println("Type the column's (attribute's) name of the first related attribute:");
		String p1 = scanner.nextLine();
		System.out.println("Type the column's (attribute's) name of the second related attribute:");
		String p2 = scanner.nextLine();
		//
		//
		//
		double marginOfError = -1;
		while (marginOfError < 0 || marginOfError > 1) {
			try {
				System.out.println("Please enter the margin of error you need (must be 0.00 <-> 1.00)");
				marginOfError = scanner.nextDouble();
				if (marginOfError > 1) {
					System.out.println("Invalid Entry!!!");
				}
			} catch (Exception e) {
				marginOfError = -1;
				System.out.println("Invalid Entry!!!");
			}
		}
		scanner.close();
		//
		//
		//
		String[] consideredAttributes = {pk, p1, p2};
		//
		//
		//
		Timestamp.addPoint();
		// STAGE 1
		DataPreProcessing s1 = new DataPreProcessing(pathOfOriginalDataSet, pathOfDataSetWithMissingValues, pathOfMissingRowsReference);
		s1.testing = updateLocations(s1);
		s1.testingComplete = s1.testing.gDataSet(true);
		s1.testingIncomplete = s1.testing.gDataSet(false);
		// STAGE 2
		DataReplacementUsingMFR s2 = new DataReplacementUsingMFR(s1.learning, s1.testingIncomplete, consideredAttributes);
		// STAGE 3
		ComputeRelativeError s3 = new ComputeRelativeError(s1.learning, s1.testingIncomplete, s2.crowdSource, s2.calculatedValues, marginOfError);
		// STAGE 4
		exportResults(s1, s2, s3);
		Timestamp.addPoint();
		// show time required to complete the algorithm
		Timestamp.printTimeToExecuteAll();
	}

	private DataSet updateLocations(DataPreProcessing s1) {
		ArrayList<RowExt> rows = new ArrayList<>();
		for (int index = 0; index < s1.testing.getRows().size(); index++) {
			int location = s1.rowsReference.getRows().get(index).getValues()[0].intValue();
			RowExt temp = new RowExt(s1.testing.getRows().get(index).getJson(), location);
			rows.add(temp);
		}
		return new DataSet(s1.testing.getAttributes(), rows);
	}

	private void exportResults(DataPreProcessing s1, DataReplacementUsingMFR s2, ComputeRelativeError s3) {
		String DIR = System.getProperty("user.home") + "/Desktop" + "/cmv_results/" + new Date().getTime() + "/";
		DataExportion.exportDataSetToPath(s1.testingComplete, DIR + "testing complete.csv");
		DataExportion.exportDataSetToPath(s1.testingIncomplete, DIR + "testing incomplete.csv");
		DataExportion.exportDataSetToPath(s2.crowdSource, DIR + "crowd source.csv");
		DataExportion.exportDataSetToPath(s2.calculatedValues, DIR + "calculated values.csv");
		DataExportion.exportDataSetToPath(s3.finalCrowdSource, DIR + "final crowd source.csv");
		DataExportion.exportDataSetToPath(s3.finalCalculatedValues, DIR + "final calculated values.csv");
	}

}
