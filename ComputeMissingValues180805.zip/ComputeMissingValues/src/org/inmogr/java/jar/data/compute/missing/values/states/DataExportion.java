package org.inmogr.java.jar.data.compute.missing.values.states;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;

import org.inmogr.java.jar.data.compute.missing.values.classes.DataSet;
import org.inmogr.java.jar.data.compute.missing.values.classes.RowExt;
import org.inmogr.java.jar.data.compute.missing.values.utils.CsvWriter;

public class DataExportion {
	
	public static boolean exportDataSetToPath(DataSet dataSet, String path) {
		try {
			File file = new File(path);
			file.getParentFile().mkdirs();
	        FileWriter writer = new FileWriter(path);
	        CsvWriter.writeLine(writer, arrayToArrayList(dataSet.getAttributes()));
	        for (RowExt row : dataSet.getRows()) {
	        	CsvWriter.writeLine(writer, row.getExportableRow());
			}
	        writer.flush();
	        writer.close();
	        return true;
		} catch (Exception e) {}
		return false;
	}

	public static ArrayList<String> arrayToArrayList(String[] array) {
		ArrayList<String> values = new ArrayList<>();
		for (String string : array) {
			values.add(string);
		}
		return values;
	}

}
