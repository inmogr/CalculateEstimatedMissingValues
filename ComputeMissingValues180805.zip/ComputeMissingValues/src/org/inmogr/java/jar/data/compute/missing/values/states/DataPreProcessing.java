package org.inmogr.java.jar.data.compute.missing.values.states;

import org.inmogr.java.jar.data.compute.missing.values.classes.DataSet;
import org.inmogr.java.jar.data.compute.missing.values.utils.CsvReader;

public class DataPreProcessing {
	
	/** is the original complete data set that will be used to compute missing values */
	public DataSet learning;
	
	/** is the the data set with missing values which needs to be computed */
	public DataSet testing;
	
	/** the row's reference if the testing data set is derived from the learning data set */
	public DataSet rowsReference;
	
	/** some times the testing data set can be decomposed of complete rows and others incomplete */
	public DataSet testingComplete, testingIncomplete;
	
	public DataPreProcessing(String pathOfOriginalDataSet, String pathOfDataSetWithMissingValues, String pathOfMissingRowsReference) {
		learning = getDataSet(pathOfOriginalDataSet);
		testing = getDataSet(pathOfDataSetWithMissingValues);
		rowsReference = getDataSet(pathOfMissingRowsReference);
	}
	
	public DataPreProcessing(String pathOfOriginalDataSet, String pathOfDataSetWithMissingValues) {
		learning = getDataSet(pathOfOriginalDataSet);
		testing = getDataSet(pathOfDataSetWithMissingValues);
		testingComplete = testing.gDataSet(true);
		testingIncomplete = testing.gDataSet(false);
	}
	
	public DataSet getDataSet(String path) {
		// pass the path to CSV Reader that will read the file and return DataSet object
		CsvReader reader = new CsvReader();
		reader.readCsv(path);
		return reader.getDataSet();
	}

}
