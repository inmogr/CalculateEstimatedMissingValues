package org.inmogr.java.jar.data.compute.missing.values.main;

import java.util.Scanner;

public class Main {
	
	public static void main (String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Please choose the algorithm to compute the missing values:");
		System.out.println("1- Replacement Algorithm V1");
		System.out.println("2- Replacement Algorithm V2");
		System.out.println("3- Replacement Algorithm V3");
		System.out.println("4- KNN Algorithm");
		System.out.println("Enter anything else to exit");
		String chooseAlgorithm = scanner.nextLine();
		scanner.close();
		switch (chooseAlgorithm) {
			case "1":
				new MainRelativesV1();
				break;
			case "2":
				new MainRelativesV2();
				break;
			case "3":
				new MainRelativesV3();
				break;
			case "4":
				new MainKNN();
				break;
		}
		System.out.println("Good bye");
	}

}
