package org.inmogr.java.jar.data.compute.missing.values.states;

import java.util.ArrayList;

import org.inmogr.java.jar.data.compute.missing.values.algorithm.ComputeMissingValuesByFrequency;
import org.inmogr.java.jar.data.compute.missing.values.classes.DataSet;
import org.inmogr.java.jar.data.compute.missing.values.classes.RowExt;

/** KNN stands for KNearestNeighbor */
public class DataReplacementUsingKNN {
	
	/** the desirable data source (must no missing values) to compute missing values */
	public DataSet learning;
	
	/** the desirable data set with missing values which needs to be computed */
	public DataSet testing;
	
	/** the result sub set with missing values that could not be computed */
	public DataSet crowdSource;
	
	/** the result sub set with missing values that have been successfully computed */
	public DataSet calculatedValues;
	
	/** desired K nearest neighbor */
	private int desiredK;
	
	public DataReplacementUsingKNN(DataSet learning, DataSet testing, int desiredK) {
		this.learning = learning;
		this.testing = testing;
		this.desiredK = desiredK;
		ArrayList<ArrayList<RowExt>> relations = findRelatedRowsForRows();
		int minimumAcceptedRelationCount = getMinimumAcceptedRelationCount(relations);
		// generates a data set to be sent to the crowd source, due the lack of information required to calculate the missing value
		generateCroudSourceDataSet(relations, minimumAcceptedRelationCount);
		// for all accepted rows calculate the missing value and generate a new data set
		generateCalculatedValuesDataSet(desiredK, relations, minimumAcceptedRelationCount);
	}

	/**
	 * Scan missing rows (row by row) and find all relations for each row
	 **/
	private ArrayList<ArrayList<RowExt>> findRelatedRowsForRows() {
		ArrayList<ArrayList<RowExt>> rows = new ArrayList<>();
		for (RowExt row : testing.getRows()) {
			rows.add(findRelatedRowsForSingleRow(row));
		}
		return rows;
	}
	
	private int getMinimumAcceptedRelationCount(ArrayList<ArrayList<RowExt>> relations) {
		/**
		 * The holder will hold all relatives of a row with missing value
		 * 		But probably there is NO rows related to a row with missing value
		 * 		Therefore, we cannot calculate the possible value of the missing value
		 * We user the average {@see avg} to set a minimum number of occurences to accept a row's relations
		 * 		By accepting a row's relations, we will replace missing values with a generated calculated value
		 * 		and by rejecting a row's relations, means we will keep the value missing and
		 * 			generate a CSV file to be given to a crowd source people who will find the missing value
		 **/
		int avg = 0;
		for (ArrayList<RowExt> list : relations) {
			// first sum all occurrences for all relations
			avg += list.size();
		}
		// get the average by dividing on the number of rows (remember each index of holder contains relations for a single row)
		avg = avg / relations.size();
		/**
		 * Real average causes eliminating acceptable number of relations
		 * 		therefore, we will accept all rows that has at least X number of relations
		 * 		where X is half of the REAL AVERAGE 
		 **/
		int min = (int) (avg * 0.5);
		min = 0; // temporary ***********************************************************************************************
		return min;
	}

	private void generateCroudSourceDataSet(ArrayList<ArrayList<RowExt>> holder, int min) {
		// the list of rows with the missing values, which could not be calculated
		ArrayList<RowExt> rows = new ArrayList<>();
		for (int index = 0; index < holder.size(); index++) {
			// because it is lower than the minimum required number of relations 
			if (holder.get(index).size() < min) {
				// since this row has less than the minimum required relations take pass it to the crowd source
				RowExt row = new RowExt(testing.getRows().get(index));
				rows.add(row);
			}
		}
		// generate the crowd source data set
		crowdSource = new DataSet(testing.getAttributes(), rows);
	}

	private void generateCalculatedValuesDataSet(int desiredK, ArrayList<ArrayList<RowExt>> holder, int min) {
		ComputeMissingValuesByFrequency cmv = new ComputeMissingValuesByFrequency();
		// the list of rows with the calculated missing values
		ArrayList<RowExt> rows = new ArrayList<>();
		for (int index = 0; index < holder.size(); index++) {
			// ignore all rows that been sent to the crowd source from being further processed
			if (holder.get(index).size() < min)
				continue;
			// get the row with missing value
			RowExt missing = new RowExt(testing.getRows().get(index));
			// pass it with its relatives to calculate the missing value
			rows.add(cmv.completeRow(missing, holder.get(index)));
		}
		// create a new data set with the calculated missing values
		calculatedValues = new DataSet(testing.getAttributes(), rows);
	}
	
	/*
	 ****************************************************************************************************
	 ****************************************************************************************************
	 ****************************************                    ****************************************
	 ****************************************      CONTINUE      ****************************************
	 ****************************************                    ****************************************
	 ****************************************************************************************************
	 ****************************************************************************************************
	 */
	
	/**
	 * Scan all complete rows (row by row) and find all relations for a specific row
	 **/
	public ArrayList<RowExt> findRelatedRowsForSingleRow(RowExt rowT) {
		ArrayList<RowExt> relatives = new ArrayList<>();
		ArrayList<Double> relativesDistance = new ArrayList<>();
		for (RowExt rowL : learning.getRows()) {
			double distanceL = calculateDistance(rowT, rowL);
			if (relatives.size() <= desiredK) {
				relatives.add(rowL);
				relativesDistance.add(distanceL);
			} else {
				int addIndex = gIndexIfWithinKNN(relativesDistance, distanceL);
				if (addIndex > -1 && addIndex < desiredK) {
					relatives.add(addIndex, rowL);
					relativesDistance.add(addIndex, distanceL);
				}
			}
		}
		return relatives;
	}

	private double calculateDistance(RowExt rowT, RowExt rowL) {
		Double[] ts = rowT.getValues(true);
		Double[] ls = rowL.getValues(true);
		if (ts.length > 0) {
			double distance = 0;
			for (int index = 0; index < ts.length; index++) {
				double temp = ts[index] - ls[index];
				temp = Math.pow(temp, 2);
				distance += temp;
			}
			distance = Math.sqrt(distance);
			return distance;
		}
		else {
			return 0;
		}
	}

	private int gIndexIfWithinKNN(ArrayList<Double> relativesDistance, double distanceL) {
		int indexC = 0;
		double distanceC = relativesDistance.get(indexC).doubleValue();
		for (int index = 1; index < relativesDistance.size(); index++) {
			if (distanceC < relativesDistance.get(index).doubleValue()) {
				indexC = index;
				distanceC = relativesDistance.get(indexC).doubleValue();
			}
		}
		if (distanceL < distanceC) {
			return indexC;
		}
		else {
			return -1;
		}
	}

}
