package org.inmogr.java.jar.data.compute.missing.values.states;

import java.util.ArrayList;

import org.inmogr.java.jar.data.compute.missing.values.algorithm.ComputeMissingValuesByFrequency;
import org.inmogr.java.jar.data.compute.missing.values.classes.DataSet;
import org.inmogr.java.jar.data.compute.missing.values.classes.RowExt;
/** MFR stands for MostFrequentRelative */
public class DataReplacementUsingMFR {
	
	/** the desirable data source (must no missing values) to compute missing values */
	public DataSet learning;
	
	/** the desirable data set with missing values which needs to be computed */
	public DataSet testing;
	
	/** the result sub set with missing values that could not be computed */
	public DataSet crowdSource;
	
	/** the result sub set with missing values that have been successfully computed */
	public DataSet calculatedValues;
	
	/** Used to determine the main attributes to be used for data comparison */
	private String[] comparativeAttributes;
	
	public DataReplacementUsingMFR(DataSet learning, DataSet testing, String[] attrs) {
		this.learning = learning;
		this.testing = testing;
		ArrayList<ArrayList<RowExt>> relations = findRelationsOfMissingValues(attrs);
		int minimumAcceptedRelationCount = getMinimumAcceptedRelationCount(attrs, relations);
		// generates a data set to be sent to the crowd source, due the lack of information required to calculate the missing value
		generateCroudSourceDataSet(relations, minimumAcceptedRelationCount);
		// for all accepted rows calculate the missing value and generate a new data set
		generateCalculatedValuesDataSet(attrs, relations, minimumAcceptedRelationCount);
	}

	private ArrayList<ArrayList<RowExt>> findRelationsOfMissingValues(String[] attrs) {
		// holds the relatives of each row depending of the 1 to 1 relations from the attributes {@see attrs} given
		ArrayList<ArrayList<RowExt>> holderRelationsDataSet = new ArrayList<>();
		// iterate over attributes to find relations in terms of two specific attributes
		for (int index = 1; index < attrs.length; index++) {
			// identify the two attributes to compare two rows' values
			String[] array = {attrs[0], attrs[index]};
			// setup the comparative attributes
			comparativeAttributes = array;
			ArrayList<ArrayList<RowExt>> holderTemporary = findRelatedRowsForRows();
			if (index == 1) // the first iteration is special case whereby there is no data yet to compare with, so just add it to the main holder
				holderRelationsDataSet.addAll(holderTemporary);
			else // next iterations, compare the current relations with the new relations then take the best
				// Check which relation is better an take it as the only relation
				holderRelationsDataSet = getBestRelation(holderRelationsDataSet, holderTemporary);
		}
		return holderRelationsDataSet;
	}

	private ArrayList<ArrayList<RowExt>> getBestRelation(ArrayList<ArrayList<RowExt>> r1, ArrayList<ArrayList<RowExt>> r2) {
		int overallR1 = 0, overallR2 = 0;
		for (int i = 0; i < r1.size(); i++) {
			overallR1 += r1.get(i).size();
			overallR2 += r2.get(i).size();
		}
		overallR1 /= r1.size();
		overallR2 /= r2.size();
		if (overallR2 > overallR1)
			return r2;
		else
			return r1;
	}

	/**
	 * Scan missing rows (row by row) and find all relations for each row
	 **/
	public ArrayList<ArrayList<RowExt>> findRelatedRowsForRows() {
		ArrayList<ArrayList<RowExt>> rows = new ArrayList<>();
		for (RowExt row : testing.getRows()) {
			rows.add(findRelatedRowsForSingleRow(row));
		}
		return rows;
	}
	
	private int getMinimumAcceptedRelationCount(String[] attrs, ArrayList<ArrayList<RowExt>> relations) {
		/**
		 * The holder will hold all relatives of a row with missing value
		 * 		But probably there is NO rows related to a row with missing value
		 * 		Therefore, we cannot calculate the possible value of the missing value
		 * We user the average {@see avg} to set a minimum number of occurences to accept a row's relations
		 * 		By accepting a row's relations, we will replace missing values with a generated calculated value
		 * 		and by rejecting a row's relations, means we will keep the value missing and
		 * 			generate a CSV file to be given to a crowd source people who will find the missing value
		 **/
		int avg = 0;
		for (ArrayList<RowExt> list : relations) {
			// first sum all occurrences for all relations
			avg += list.size();
		}
		// get the average by dividing on the number of rows (remember each index of holder contains relations for a single row)
		avg = avg / relations.size();
		/**
		 * Real average causes eliminating acceptable number of relations
		 * 		therefore, we will accept all rows that has at least X number of relations
		 * 		where X is half of the REAL AVERAGE 
		 **/
		int min = (int) (avg * 0.5);
		return min;
	}

	private void generateCroudSourceDataSet(ArrayList<ArrayList<RowExt>> holder, int min) {
		// the list of rows with the missing values, which could not be calculated
		ArrayList<RowExt> rows = new ArrayList<>();
		for (int index = 0; index < holder.size(); index++) {
			// because it is lower than the minimum required number of relations 
			if (holder.get(index).size() < min) {
				// since this row has less than the minimum required relations take pass it to the crowd source
				RowExt row = new RowExt(testing.getRows().get(index));
				rows.add(row);
			}
		}
		// generate the crowd source data set
		crowdSource = new DataSet(testing.getAttributes(), rows);
	}

	private void generateCalculatedValuesDataSet(String[] attrs, ArrayList<ArrayList<RowExt>> holder, int min) {
		ComputeMissingValuesByFrequency cmv = new ComputeMissingValuesByFrequency();
		// the list of rows with the calculated missing values
		ArrayList<RowExt> rows = new ArrayList<>();
		for (int index = 0; index < holder.size(); index++) {
			// ignore all rows that been sent to the crowd source from being further processed
			if (holder.get(index).size() < min)
				continue;
			// get the row with missing value
			RowExt missing = new RowExt(testing.getRows().get(index));
			// pass it with its relatives to calculate the missing value
			rows.add(cmv.completeRow(missing, holder.get(index)));
		}
		// create a new data set with the calculated missing values
		calculatedValues = new DataSet(testing.getAttributes(), rows);
	}
	
	/*
	 ****************************************************************************************************
	 ****************************************************************************************************
	 ****************************************                    ****************************************
	 ****************************************      CONTINUE      ****************************************
	 ****************************************                    ****************************************
	 ****************************************************************************************************
	 ****************************************************************************************************
	 */
	
	/**
	 * Scan all complete rows (row by row) and find all relations for a specific row
	 **/
	public ArrayList<RowExt> findRelatedRowsForSingleRow(RowExt rowM) {
		ArrayList<RowExt> relative = new ArrayList<>();
		for (RowExt rowC : learning.getRows()) {
			if (hasRelation(rowM, rowC))
				relative.add(rowC);
		}
		return relative;
	}
	
	/**
	 * Check if two rows has a relation if their values are relative within selected attributes {@see comparativeAttributes}
	 **/
	public boolean hasRelation(RowExt row1, RowExt row2) {
		for (String attributeName : comparativeAttributes) {
			// get the value from the first row at specific attribute
			double value1 = row1.getValue(attributeName);
			// get the value from the second row at the same specific attribute
			double value2 = row2.getValue(attributeName);
			// compare the two values, whether it is close or not
			if (isRelativeValues(value1, value2) == false)
				return false;
		}
		// since we arrived then all values within the selected attributes are close to each other
		// therefore, the two rows has a relation between each other
		return true;
	}
	
	/**
	 * Checks if two double values are close to each other with some margin of error defined as {@see estimatedCloser}
	 **/
	private boolean isRelativeValues(double val1, double val2) {
		// reflects the margin of error accepted between two values to consider it close to each other
		double estimatedCloser = 0.99;
		// if any of the values are ZERO then we cannot compare so just return true
		if (val1 == 0 || val2 == 0) return true;
		// check if first value is greater than the second value
		if (val1 > val2)
			// if greater then divide the smaller on the greater and compare with the margin of error 
			return (val2 / val1) >= estimatedCloser;
		// check if first value is smaller than the second value
		else if (val1 < val2)
			// if smaller then divide the smaller on the greater and compare with the margin of error
			return (val1 / val2) >= estimatedCloser;
		// arriving to this point means the two values are identical or equal
		else return true;
	}

}
